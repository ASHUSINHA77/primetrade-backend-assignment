import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "path";
import fs from "fs";
import * as yaml from "js-yaml";
import swaggerUi from "swagger-ui-express";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const workspaceRoot = process.cwd().endsWith(path.join("artifacts", "api-server"))
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const specPath = path.resolve(workspaceRoot, "lib/api-spec/openapi.yaml");
try {
  const specContent = fs.readFileSync(specPath, "utf-8");
  const swaggerSpec = yaml.load(specContent) as Record<string, unknown>;
  app.use("/api/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
    customSiteTitle: "TaskFlow API Docs",
    swaggerOptions: {
      persistAuthorization: true,
    },
  }));
  logger.info("Swagger UI available at /api/docs");
} catch (err) {
  logger.warn({ err }, "Could not load OpenAPI spec for Swagger UI");
}

app.use("/api", router);

export default app;
