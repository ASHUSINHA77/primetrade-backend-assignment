import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, tasksTable } from "@workspace/db";
import { DeleteUserParams } from "@workspace/api-zod";
import { authenticate, requireAdmin } from "../../middlewares/auth";

const router: IRouter = Router();

router.use(authenticate, requireAdmin);

router.get("/v1/admin/users", async (req, res): Promise<void> => {
  const users = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      createdAt: usersTable.createdAt,
    })
    .from(usersTable)
    .orderBy(usersTable.createdAt);

  res.json(
    users.map((u) => ({
      ...u,
      createdAt: u.createdAt.toISOString(),
    }))
  );
});

router.delete("/v1/admin/users/:id", async (req, res): Promise<void> => {
  const params = DeleteUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  if (params.data.id === req.user!.userId) {
    res.status(400).json({ error: "Cannot delete your own account" });
    return;
  }

  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.id, params.data.id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  await db.delete(usersTable).where(eq(usersTable.id, params.data.id));

  req.log.info({ deletedUserId: params.data.id, adminId: req.user!.userId }, "User deleted by admin");
  res.sendStatus(204);
});

router.get("/v1/admin/stats", async (req, res): Promise<void> => {
  const [users, tasks] = await Promise.all([
    db.select({ id: usersTable.id }).from(usersTable),
    db
      .select({ status: tasksTable.status, priority: tasksTable.priority })
      .from(tasksTable),
  ]);

  const totalUsers = users.length;
  const totalTasks = tasks.length;

  const tasksByStatus = {
    total: totalTasks,
    pending: tasks.filter((t) => t.status === "pending").length,
    in_progress: tasks.filter((t) => t.status === "in_progress").length,
    done: tasks.filter((t) => t.status === "done").length,
    high_priority: tasks.filter((t) => t.priority === "high").length,
  };

  const tasksByPriority = {
    low: tasks.filter((t) => t.priority === "low").length,
    medium: tasks.filter((t) => t.priority === "medium").length,
    high: tasks.filter((t) => t.priority === "high").length,
  };

  res.json({ totalUsers, totalTasks, tasksByStatus, tasksByPriority });
});

export default router;
