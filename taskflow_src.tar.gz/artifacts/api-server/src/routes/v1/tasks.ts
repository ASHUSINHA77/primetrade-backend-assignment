import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, tasksTable } from "@workspace/db";
import {
  CreateTaskBody,
  UpdateTaskBody,
  ListTasksQueryParams,
  GetTaskParams,
  UpdateTaskParams,
  DeleteTaskParams,
} from "@workspace/api-zod";
import { authenticate } from "../../middlewares/auth";

const router: IRouter = Router();

router.use(authenticate);

function taskToJson(task: typeof tasksTable.$inferSelect) {
  return {
    id: task.id,
    userId: task.userId,
    title: task.title,
    description: task.description ?? null,
    status: task.status,
    priority: task.priority,
    createdAt: task.createdAt.toISOString(),
    updatedAt: task.updatedAt.toISOString(),
  };
}

router.get("/v1/tasks/stats", async (req, res): Promise<void> => {
  const userId = req.user!.userId;
  const isAdmin = req.user!.role === "admin";

  const baseFilter = isAdmin ? sql`1=1` : eq(tasksTable.userId, userId);

  const rows = await db
    .select({
      status: tasksTable.status,
      priority: tasksTable.priority,
    })
    .from(tasksTable)
    .where(baseFilter);

  const stats = {
    total: rows.length,
    pending: rows.filter((r) => r.status === "pending").length,
    in_progress: rows.filter((r) => r.status === "in_progress").length,
    done: rows.filter((r) => r.status === "done").length,
    high_priority: rows.filter((r) => r.priority === "high").length,
  };

  res.json(stats);
});

router.get("/v1/tasks", async (req, res): Promise<void> => {
  const queryParams = ListTasksQueryParams.safeParse(req.query);
  if (!queryParams.success) {
    res.status(400).json({ error: queryParams.error.message });
    return;
  }

  const userId = req.user!.userId;
  const isAdmin = req.user!.role === "admin";

  let query = db.select().from(tasksTable).$dynamic();

  const conditions = [];

  if (!isAdmin) {
    conditions.push(eq(tasksTable.userId, userId));
  }

  if (queryParams.data.status) {
    conditions.push(eq(tasksTable.status, queryParams.data.status));
  }

  if (queryParams.data.priority) {
    conditions.push(eq(tasksTable.priority, queryParams.data.priority));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  const tasks = await query.orderBy(tasksTable.createdAt);
  res.json(tasks.map(taskToJson));
});

router.post("/v1/tasks", async (req, res): Promise<void> => {
  const parsed = CreateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userId = req.user!.userId;

  const [task] = await db
    .insert(tasksTable)
    .values({
      userId,
      title: parsed.data.title,
      description: parsed.data.description ?? null,
      status: (parsed.data.status ?? "pending") as "pending" | "in_progress" | "done",
      priority: (parsed.data.priority ?? "medium") as "low" | "medium" | "high",
    })
    .returning();

  req.log.info({ taskId: task.id, userId }, "Task created");
  res.status(201).json(taskToJson(task));
});

router.get("/v1/tasks/:id", async (req, res): Promise<void> => {
  const params = GetTaskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [task] = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.id, params.data.id))
    .limit(1);

  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  const isAdmin = req.user!.role === "admin";
  if (!isAdmin && task.userId !== req.user!.userId) {
    res.status(403).json({ error: "You do not have access to this task" });
    return;
  }

  res.json(taskToJson(task));
});

router.patch("/v1/tasks/:id", async (req, res): Promise<void> => {
  const params = UpdateTaskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.id, params.data.id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  const isAdmin = req.user!.role === "admin";
  if (!isAdmin && existing.userId !== req.user!.userId) {
    res.status(403).json({ error: "You do not have access to this task" });
    return;
  }

  const updateData: Partial<typeof tasksTable.$inferInsert> = {};
  if (parsed.data.title !== undefined) updateData.title = parsed.data.title;
  if (parsed.data.description !== undefined) updateData.description = parsed.data.description;
  if (parsed.data.status !== undefined)
    updateData.status = parsed.data.status as "pending" | "in_progress" | "done";
  if (parsed.data.priority !== undefined)
    updateData.priority = parsed.data.priority as "low" | "medium" | "high";

  const [updated] = await db
    .update(tasksTable)
    .set(updateData)
    .where(eq(tasksTable.id, params.data.id))
    .returning();

  req.log.info({ taskId: updated.id }, "Task updated");
  res.json(taskToJson(updated));
});

router.delete("/v1/tasks/:id", async (req, res): Promise<void> => {
  const params = DeleteTaskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [existing] = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.id, params.data.id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  const isAdmin = req.user!.role === "admin";
  if (!isAdmin && existing.userId !== req.user!.userId) {
    res.status(403).json({ error: "You do not have access to this task" });
    return;
  }

  await db.delete(tasksTable).where(eq(tasksTable.id, params.data.id));

  req.log.info({ taskId: params.data.id }, "Task deleted");
  res.sendStatus(204);
});

export default router;
