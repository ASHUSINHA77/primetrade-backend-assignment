import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./v1/auth";
import tasksRouter from "./v1/tasks";
import adminRouter from "./v1/admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(tasksRouter);
router.use(adminRouter);

export default router;
