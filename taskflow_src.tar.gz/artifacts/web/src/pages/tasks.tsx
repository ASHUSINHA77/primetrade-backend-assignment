import React, { useState } from "react";
import { 
  useListTasks, 
  useUpdateTask, 
  useDeleteTask, 
  getListTasksQueryKey,
  getGetTaskStatsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Loader2,
  MoreVertical,
  Edit2,
  Trash2,
  Calendar,
  AlertCircle,
  FilterX
} from "lucide-react";
import { format } from "date-fns";

export default function Tasks() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  
  const [taskToDelete, setTaskToDelete] = useState<number | null>(null);
  const [taskToEdit, setTaskToEdit] = useState<any>(null);

  const queryParams = {
    ...(statusFilter !== "all" && { status: statusFilter as any }),
    ...(priorityFilter !== "all" && { priority: priorityFilter as any }),
  };

  const { data: tasks, isLoading, isFetching } = useListTasks(queryParams, {
    query: {
      queryKey: getListTasksQueryKey(queryParams)
    }
  });

  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();

  const handleStatusChange = (id: number, status: string) => {
    updateTask.mutate({ id, data: { status: status as any } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetTaskStatsQueryKey() });
        toast({ title: "Status updated" });
      }
    });
  };

  const handleDelete = () => {
    if (!taskToDelete) return;
    deleteTask.mutate({ id: taskToDelete }, {
      onSuccess: () => {
        setTaskToDelete(null);
        queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetTaskStatsQueryKey() });
        toast({ title: "Task deleted successfully" });
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Error deleting task", description: err.message });
      }
    });
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskToEdit) return;

    updateTask.mutate({ 
      id: taskToEdit.id, 
      data: {
        title: taskToEdit.title,
        description: taskToEdit.description,
        priority: taskToEdit.priority,
        status: taskToEdit.status
      }
    }, {
      onSuccess: () => {
        setTaskToEdit(null);
        queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetTaskStatsQueryKey() });
        toast({ title: "Task updated successfully" });
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Update failed", description: err.message });
      }
    });
  };

  const clearFilters = () => {
    setStatusFilter("all");
    setPriorityFilter("all");
  };

  const statusColors: Record<string, string> = {
    pending: "bg-amber-500/10 text-amber-500 hover:bg-amber-500/20 border-amber-500/20",
    in_progress: "bg-indigo-500/10 text-indigo-500 hover:bg-indigo-500/20 border-indigo-500/20",
    done: "bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 border-emerald-500/20"
  };

  const priorityColors: Record<string, string> = {
    low: "text-muted-foreground bg-muted hover:bg-muted/80",
    medium: "bg-blue-500/10 text-blue-500 hover:bg-blue-500/20 border-blue-500/20",
    high: "bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 border-rose-500/20"
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tasks</h1>
          <p className="text-muted-foreground mt-1">Manage and track your workload.</p>
        </div>

        <div className="flex flex-wrap items-center gap-3 bg-card p-2 rounded-xl border border-border shadow-sm">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px] h-9 border-none bg-transparent shadow-none focus:ring-0">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="done">Done</SelectItem>
            </SelectContent>
          </Select>

          <div className="w-px h-6 bg-border mx-1" />

          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-[140px] h-9 border-none bg-transparent shadow-none focus:ring-0">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
            </SelectContent>
          </Select>

          {(statusFilter !== "all" || priorityFilter !== "all") && (
            <>
              <div className="w-px h-6 bg-border mx-1" />
              <Button variant="ghost" size="icon" onClick={clearFilters} className="h-9 w-9 text-muted-foreground hover:text-foreground" title="Clear Filters">
                <FilterX size={16} />
              </Button>
            </>
          )}
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : tasks?.length === 0 ? (
        <div className="text-center py-24 bg-card rounded-xl border border-dashed border-border flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
            <AlertCircle size={32} className="text-muted-foreground opacity-50" />
          </div>
          <h3 className="text-lg font-semibold">No tasks found</h3>
          <p className="text-muted-foreground mt-1 max-w-sm">
            {(statusFilter !== "all" || priorityFilter !== "all") 
              ? "No tasks match your current filters. Try adjusting them." 
              : "You don't have any tasks yet. Create one from the Dashboard."}
          </p>
          {(statusFilter !== "all" || priorityFilter !== "all") && (
            <Button variant="outline" onClick={clearFilters} className="mt-6">
              Clear Filters
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 relative">
          {isFetching && (
            <div className="absolute inset-0 bg-background/50 backdrop-blur-sm z-10 flex items-center justify-center rounded-xl">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          )}
          {tasks?.map((task) => (
            <Card key={task.id} className="flex flex-col shadow-sm border-border hover:shadow-md transition-shadow">
              <CardContent className="flex-1 p-5">
                <div className="flex justify-between items-start gap-4 mb-3">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className={statusColors[task.status]}>
                      {task.status.replace("_", " ").toUpperCase()}
                    </Badge>
                    <Badge variant="outline" className={priorityColors[task.priority]}>
                      {task.priority.toUpperCase()}
                    </Badge>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 -mr-2 text-muted-foreground hover:text-foreground">
                        <MoreVertical size={16} />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setTaskToEdit(task)}>
                        <Edit2 size={14} className="mr-2" /> Edit Task
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel>Change Status</DropdownMenuLabel>
                      <DropdownMenuItem onClick={() => handleStatusChange(task.id, "pending")} disabled={task.status === "pending"}>
                        Pending
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleStatusChange(task.id, "in_progress")} disabled={task.status === "in_progress"}>
                        In Progress
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleStatusChange(task.id, "done")} disabled={task.status === "done"}>
                        Done
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setTaskToDelete(task.id)}>
                        <Trash2 size={14} className="mr-2" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <h3 className="font-semibold text-lg leading-tight mb-2 text-foreground line-clamp-2">
                  {task.title}
                </h3>
                {task.description && (
                  <p className="text-sm text-muted-foreground line-clamp-3">
                    {task.description}
                  </p>
                )}
              </CardContent>
              <CardFooter className="p-5 pt-0 mt-auto flex items-center justify-between border-t border-border/50 bg-muted/20 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5 mt-3">
                  <Calendar size={14} />
                  <span>{format(new Date(task.createdAt), "MMM d, yyyy")}</span>
                </div>
                {task.updatedAt !== task.createdAt && (
                  <span className="mt-3">Edited</span>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Delete Confirmation */}
      <AlertDialog open={!!taskToDelete} onOpenChange={(open) => !open && setTaskToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Task</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this task? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {deleteTask.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Dialog */}
      <Dialog open={!!taskToEdit} onOpenChange={(open) => !open && setTaskToEdit(null)}>
        <DialogContent className="sm:max-w-[425px]">
          <form onSubmit={handleEditSubmit}>
            <DialogHeader>
              <DialogTitle>Edit Task</DialogTitle>
              <DialogDescription>
                Make changes to your task.
              </DialogDescription>
            </DialogHeader>
            {taskToEdit && (
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-title">Title</Label>
                  <Input 
                    id="edit-title" 
                    value={taskToEdit.title}
                    onChange={(e) => setTaskToEdit({...taskToEdit, title: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-description">Description</Label>
                  <Textarea 
                    id="edit-description" 
                    value={taskToEdit.description || ""}
                    onChange={(e) => setTaskToEdit({...taskToEdit, description: e.target.value})}
                    className="resize-none h-20"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-status">Status</Label>
                    <Select 
                      value={taskToEdit.status} 
                      onValueChange={(val: any) => setTaskToEdit({...taskToEdit, status: val})}
                    >
                      <SelectTrigger id="edit-status">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="done">Done</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-priority">Priority</Label>
                    <Select 
                      value={taskToEdit.priority} 
                      onValueChange={(val: any) => setTaskToEdit({...taskToEdit, priority: val})}
                    >
                      <SelectTrigger id="edit-priority">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setTaskToEdit(null)}>Cancel</Button>
              <Button type="submit" disabled={!taskToEdit?.title?.trim() || updateTask.isPending}>
                {updateTask.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save Changes
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
