import React, { useState } from "react";
import { useAuth } from "@/lib/auth";
import { 
  useGetAdminStats, 
  useListUsers, 
  useDeleteUser,
  getListUsersQueryKey,
  getGetAdminStatsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Users, 
  ListTodo, 
  ShieldAlert,
  Shield,
  User as UserIcon,
  Trash2,
  Loader2,
  Calendar
} from "lucide-react";
import { format } from "date-fns";

export default function Admin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [userToDelete, setUserToDelete] = useState<number | null>(null);

  // If somehow a non-admin gets here (though layout protects), show access denied
  if (user?.role !== "admin") {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
        <div className="w-16 h-16 bg-destructive/10 text-destructive rounded-full flex items-center justify-center">
          <ShieldAlert size={32} />
        </div>
        <h1 className="text-2xl font-bold">Access Denied</h1>
        <p className="text-muted-foreground">You do not have permission to view this page.</p>
      </div>
    );
  }

  const { data: stats, isLoading: statsLoading } = useGetAdminStats();
  const { data: users, isLoading: usersLoading } = useListUsers();
  const deleteUser = useDeleteUser();

  const handleDeleteUser = () => {
    if (!userToDelete) return;
    deleteUser.mutate({ id: userToDelete }, {
      onSuccess: () => {
        setUserToDelete(null);
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
        toast({ title: "User deleted successfully" });
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Failed to delete user", description: err.message });
        setUserToDelete(null);
      }
    });
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Admin Console</h1>
        <p className="text-muted-foreground mt-1">Platform-wide statistics and user management.</p>
      </div>

      {statsLoading ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="shadow-sm border-border bg-gradient-to-br from-card to-primary/5">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                <Users size={24} />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                <p className="text-3xl font-bold font-mono">{stats?.totalUsers || 0}</p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-sm border-border bg-gradient-to-br from-card to-indigo-500/5">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                <ListTodo size={24} />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Tasks</p>
                <p className="text-3xl font-bold font-mono">{stats?.totalTasks || 0}</p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-sm border-border">
            <CardContent className="p-6">
              <p className="text-sm font-medium text-muted-foreground mb-4">Task Status Breakdown</p>
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-amber-500 font-medium">Pending</span>
                  <span className="font-mono">{stats?.tasksByStatus.pending || 0}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-indigo-500 font-medium">In Progress</span>
                  <span className="font-mono">{stats?.tasksByStatus.in_progress || 0}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-emerald-500 font-medium">Done</span>
                  <span className="font-mono">{stats?.tasksByStatus.done || 0}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm border-border">
            <CardContent className="p-6">
              <p className="text-sm font-medium text-muted-foreground mb-4">Priority Distribution</p>
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-rose-500 font-medium">High</span>
                  <span className="font-mono">{stats?.tasksByPriority.high || 0}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-blue-500 font-medium">Medium</span>
                  <span className="font-mono">{stats?.tasksByPriority.medium || 0}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground font-medium">Low</span>
                  <span className="font-mono">{stats?.tasksByPriority.low || 0}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Card className="shadow-sm border-border">
        <CardHeader>
          <CardTitle>User Management</CardTitle>
        </CardHeader>
        <CardContent>
          {usersLoading ? (
            <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
          ) : (
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader className="bg-muted/50">
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users?.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs">
                            {u.name.charAt(0).toUpperCase()}
                          </div>
                          {u.name}
                          {u.id === user.id && (
                            <Badge variant="outline" className="ml-2 bg-primary/5 text-primary text-[10px] py-0 h-4">You</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{u.email}</TableCell>
                      <TableCell>
                        {u.role === "admin" ? (
                          <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                            <Shield size={12} className="mr-1" /> Admin
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20">
                            <UserIcon size={12} className="mr-1" /> User
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        <div className="flex items-center gap-1.5">
                          <Calendar size={14} />
                          {format(new Date(u.createdAt), "MMM d, yyyy")}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                          disabled={u.id === user.id} // Cannot delete self
                          onClick={() => setUserToDelete(u.id)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {users?.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                        No users found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!userToDelete} onOpenChange={(open) => !open && setUserToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete User</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this user? This action will permanently remove the user and all their tasks.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteUser} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {deleteUser.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Delete User"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
