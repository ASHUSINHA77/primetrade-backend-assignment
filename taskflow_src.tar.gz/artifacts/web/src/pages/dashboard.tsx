import React, { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useGetTaskStats, useCreateTask, getGetTaskStatsQueryKey, getListTasksQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ListTodo,
  Plus,
  ArrowRight,
  TrendingUp,
  Loader2
} from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  
  const { data: stats, isLoading: statsLoading } = useGetTaskStats();
  const createTask = useCreateTask();

  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    priority: "medium" as "low" | "medium" | "high",
    status: "pending" as "pending" | "in_progress" | "done"
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.title.trim()) return;

    createTask.mutate({ data: newTask }, {
      onSuccess: () => {
        setIsCreateOpen(false);
        setNewTask({ title: "", description: "", priority: "medium", status: "pending" });
        toast({ title: "Task created successfully" });
        queryClient.invalidateQueries({ queryKey: getGetTaskStatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });
      },
      onError: (err: any) => {
        toast({ 
          variant: "destructive", 
          title: "Failed to create task", 
          description: err.message || "An error occurred" 
        });
      }
    });
  };

  if (statsLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const statCards = [
    { 
      title: "Total Tasks", 
      value: stats?.total || 0, 
      icon: ListTodo, 
      color: "text-blue-500",
      bg: "bg-blue-500/10"
    },
    { 
      title: "Pending", 
      value: stats?.pending || 0, 
      icon: AlertCircle, 
      color: "text-amber-500",
      bg: "bg-amber-500/10"
    },
    { 
      title: "In Progress", 
      value: stats?.in_progress || 0, 
      icon: Clock, 
      color: "text-indigo-500",
      bg: "bg-indigo-500/10"
    },
    { 
      title: "Done", 
      value: stats?.done || 0, 
      icon: CheckCircle2, 
      color: "text-emerald-500",
      bg: "bg-emerald-500/10"
    },
    { 
      title: "High Priority", 
      value: stats?.high_priority || 0, 
      icon: TrendingUp, 
      color: "text-rose-500",
      bg: "bg-rose-500/10"
    },
  ];

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back, {user?.name.split(" ")[0]}</h1>
          <p className="text-muted-foreground mt-1">Here is the overview of your task landscape.</p>
        </div>
        <div className="flex items-center gap-3">
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 shadow-sm">
                <Plus size={16} />
                New Task
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <form onSubmit={handleCreateTask}>
                <DialogHeader>
                  <DialogTitle>Create Task</DialogTitle>
                  <DialogDescription>
                    Add a new task to your workspace.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Title</Label>
                    <Input 
                      id="title" 
                      value={newTask.title}
                      onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                      placeholder="e.g. Implement JWT Auth" 
                      autoFocus
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description (optional)</Label>
                    <Textarea 
                      id="description" 
                      value={newTask.description}
                      onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                      placeholder="Add details about this task..."
                      className="resize-none h-20"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="status">Status</Label>
                      <Select 
                        value={newTask.status} 
                        onValueChange={(val: any) => setNewTask({...newTask, status: val})}
                      >
                        <SelectTrigger id="status">
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="done">Done</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="priority">Priority</Label>
                      <Select 
                        value={newTask.priority} 
                        onValueChange={(val: any) => setNewTask({...newTask, priority: val})}
                      >
                        <SelectTrigger id="priority">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={!newTask.title.trim() || createTask.isPending}>
                    {createTask.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Create
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {statCards.map((stat, i) => (
          <Card key={i} className="shadow-sm border-border overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                  <p className="text-3xl font-bold font-mono mt-1">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${stat.bg} ${stat.color}`}>
                  <stat.icon size={24} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-10 text-center text-muted-foreground border-2 border-dashed border-border rounded-xl">
              <ListTodo size={32} className="mb-3 opacity-20" />
              <p>Navigate to Tasks to see detailed activity.</p>
              <Button variant="link" onClick={() => setLocation("/tasks")} className="mt-2 text-primary">
                View all tasks <ArrowRight size={16} className="ml-1" />
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="text-primary">Getting Started</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">Welcome to TaskFlow. Here are some quick tips to get you up and running:</p>
            <ul className="text-sm space-y-2 list-disc pl-4 text-muted-foreground">
              <li>Create tasks using the "New Task" button above</li>
              <li>Filter and manage your tasks on the Tasks page</li>
              <li>Set priorities to keep track of urgent items</li>
              <li>{user?.role === "admin" ? "Access the Admin Console to view user statistics" : "Complete tasks to see your stats grow"}</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
