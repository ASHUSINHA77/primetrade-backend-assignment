import React, { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { useLocation } from "wouter";
import { useGetMe } from "@workspace/api-client-react";
import { UserProfile } from "@workspace/api-client-react/src/generated/api.schemas";

interface AuthContextType {
  token: string | null;
  user: UserProfile | null;
  isLoading: boolean;
  login: (token: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(
    typeof window !== "undefined" ? window.localStorage.getItem("taskflow_token") : null
  );
  const [, setLocation] = useLocation();

  const { data: user, isLoading: isUserLoading, isError } = useGetMe({
    query: {
      enabled: !!token,
      retry: false,
    },
  });

  useEffect(() => {
    if (isError) {
      // 401 or other error, clear token
      logout();
    }
  }, [isError]);

  const login = (newToken: string) => {
    window.localStorage.setItem("taskflow_token", newToken);
    setToken(newToken);
  };

  const logout = () => {
    window.localStorage.removeItem("taskflow_token");
    setToken(null);
    setLocation("/login");
  };

  // True loading state is when we have a token but haven't fetched the user yet
  const isLoading = !!token && isUserLoading;

  return (
    <AuthContext.Provider value={{ token, user: user || null, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
